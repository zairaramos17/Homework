let angle = 0;
let x = 200;
let y = 40;
let s = 90;
let value = 0;

function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(0);
  
  countdown();
  
  spin(0.02);
  
  if (mouseIsPressed) {
    stroke(237, 34, 93);
    strokeWeight(2);
  }
  line(mouseX - 66, mouseY, mouseX + 66, mouseY);
  line(mouseX, mouseY - 66, mouseX, mouseY + 66);

  fill(value);
  
}

function countdown(){
  push(); //save coordinate system 1
  //"defining coordinate system 2"
  
  translate(width/2, height/2);
  rotate(angle);
  ellipse(x,y,s,s);
  ellipse(x,y,s-20,s-20);
  ellipse(x,y,s-40,s-40);
  ellipse(x,y,s-60,s-60);
  ellipse(x,y,s-80,s-80);
  ellipse(x-90,y-90,s,s);
  ellipse(x-90,y-90,s-20,s-20);
  ellipse(x-90,y-90,s-40,s-40);
  ellipse(x-90,y-90,s-60,s-60);
  ellipse(x-90,y-90,s-80,s-80);
  fill (237, 34, 93);
  
  pop(); //revert back coordinate system 1
}


function spin(v){
  angle += v ;
}
//target circles change to white
function mouseClicked() {
  if (value === 255) {
    value = 0;
  } else {
    value = 255;
  }
}
